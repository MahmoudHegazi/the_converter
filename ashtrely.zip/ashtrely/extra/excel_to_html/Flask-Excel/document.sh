python setup.py install
sphinx-build -b html docs/source docs/build
